import 'package:flutter/material.dart';
import 'package:shopping_app/core/models/products_model.dart';

class Cart extends ChangeNotifier {
  List<ProductModel> _cartItems = [];

  List<ProductModel> get items => _cartItems;

  int get cartLength => _cartItems.length;

  double get totalPrice => _cartItems.fold(
      0, (total, accumulate) => total + accumulate.price * accumulate.quantity);

  void addItemToCart(ProductModel item) {
    debugPrint("Add to Item Called");
    debugPrint("item quantity: ${item.quantity}");
    if (_cartItems.contains(item)) {
      // debugPrint("item is already added");
      // debugPrint("items length: ${_cartItems.length}");
      _cartItems = _cartItems.map((cartItem) {
        // debugPrint("iterating via map");
        if (cartItem.id == item.id) {
          // debugPrint("Items matched");
          cartItem.quantity = cartItem.quantity + 1;
          return cartItem;
        } else {
          // debugPrint("Items couldn't added");
          return cartItem;
        }
      }).toList();
    } else {
      item.quantity = 1;
      _cartItems.add(item);
    }
    notifyListeners();
  }

  void removeItemFromCart(int id) {
    _cartItems.removeWhere((element) => element.id == id);
    notifyListeners();
  }

  void removeAllItemsFromCart() {
    _cartItems.clear();
    notifyListeners();
  }
}
