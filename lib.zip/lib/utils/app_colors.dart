import 'dart:ui';

class AppColors {
  static const Color primaryColor = Color.fromARGB(255, 169, 148, 252);
  static const Color secondaryColor = Color.fromARGB(255, 220, 212, 248);
}
