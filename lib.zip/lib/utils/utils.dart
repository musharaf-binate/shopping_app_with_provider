class Utils {
  static String shortenTitle(String value) {
    return "${value.split(" ")[0]} ${value.split(" ")[1]}";
  }
}
